#DSA-Assgn-8

#This assignment needs DataStructures.py file in your package, you can get it from resources page

from datastruct.DataStructures import LinkedList

class BakeHouse:
    def __init__(self):
        self.__occupied_table_list=LinkedList()

    def get_occupied_table_list(self):
        return self.__occupied_table_list

    def allocate_table(self):
        temp=self.__occupied_table_list.get_head()
        if (temp==None):
            self.__occupied_table_list.add(1)
        else:
            if temp.get_data()!=1:
                self.__occupied_table_list.insert(1,None)
            elif:
                while(temp):
                    if temp.get_data()
                self.__occupied_table_list.insert(i,i-1)
            else:
                print("Error: No seats")
            
        c=1
        while(temp):
            if temp.get_data()==None:
                temp.set_data(c)
                return
            else:
                c+=1
                temp=temp.get_next()
            
    def deallocate_table(self,table_number):
        self.__occupied_table_list.delete(table_number)
        
    #Implement other methods here

bakehouse=BakeHouse()
#Invoke the methods of BakeHouse class and test the program