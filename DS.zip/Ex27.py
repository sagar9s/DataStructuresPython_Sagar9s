#DSA-Exer-27
import itertools

my_c = []

def max_sum_is(num_list):
    lst=[]
    sublist=[]
    lst1=[]
    lst.append(num_list[0])
    num_list1=sorted(num_list)
    if num_list==num_list1:
        return sum(num_list)
    elif max(num_list)==num_list[0]:
        return max(num_list)
    else:
        for x in range(1, len(num_list)+1):
            my_c.extend(list(itertools.combinations(num_list,x)))


        for i in sublist:
            lst1.append(sum(i))
        return max(lst1)
         
              
                
            


#Pass different values to the function and test your program
num_list=[45, 78, 22, 42, 12, 3, 78]
print("Sum of the maximum sum increasing subsequence is :" ,max_sum_is(num_list))
