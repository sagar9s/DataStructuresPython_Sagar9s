#PF-Assgn-103

def fun(input_list):
    lst=[]
    lst1=[]
    lst2=[]
    lst_left=[]
    lst_right=[]
    output_list=[]
    for i in input_list:
        lst.append(i.split(":"))
    for i in range(0,len(lst)):
        lst_left.append(lst[i][0])
        lst_right.append(lst[i][1])
    for i in lst_left:
        
        str1=""
        cnt=-1
        for j in i:
            cnt+=1
            if j.isalpha():
                str1+=str(cnt)
        if str1=="":
            lst1.append("X")
        else:
            lst1.append(str1)
    for i in lst_right:
        
        str1=""
        cnt=-1
        for j in i:
            cnt+=1
            if j.isdigit():
                str1+=str(cnt)
        if str1=="":
            lst2.append("Y")
        else:
            lst2.append(str1)
    
    for i in range(0,len(lst1)):
        str2=""
        str2+=lst1[i]+":"+lst2[i]
        output_list.append(str2)
        
    
    return output_list

input_list = ['1234:abcd','abcd:1234']
output_list = fun(input_list)
print(output_list)
