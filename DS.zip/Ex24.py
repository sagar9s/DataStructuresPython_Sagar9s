#DSA-Exer-24

def make_change(denomination_list, amount):
    '''Remove pass and implement the Greedy approach to make the change for the amount using the currencies in the denomination list.
    The function should return the total number of notes needed to make the change. If change cannot be obtained for the given amount, then return -1. Return 1 if the amount is equal to one of the currencies available in the denomination list.  '''
    if amount in denomination_list:
        return 1
    elif 1 not in denomination_list:
        cnt=0
        for i in denomination_list:
            if i>amount:
                cnt+=1
        if cnt==len(denomination_list):
            return -1
    else:
        denomination_list.sort(reverse=True)
        for i in denomination_list:
            
           
            if amount//i==0:
                return amount//i
            else:
                x=amount%i
                if denomination_list[1]<x:
                    y=x//denomination_list[1]
                    return denomination_list[len(denomination_list)-1
                    ]+amount//i+y
                else:
                    
                    y=x//denomination_list[2]
                    return amount//i+y
            

#Pass different values to the function and test your program
amount= 50
denomination_list = [15,10]
print(make_change(denomination_list, amount))
