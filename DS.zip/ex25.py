#DSA-Exer-25

def find_maximum_activities(activity_list,start_time_list, finish_time_list):
    lst=[]
    mapped=list(zip(activity_list,start_time_list,finish_time_list))
    mapped.sort(key=lambda x:x[2],reverse=False)
    x=0
    for i in range(0,len(mapped)):
        if 
            lst.append(i[0])
    return lst
#Pass different values to the function and test your program
activity_list=[1, 2, 3, 4, 5, 6]
start_time_list=[5, 4, 8, 2, 3, 1]
finish_time_list=[13, 6, 16, 7, 5, 4]

print("Activities:",activity_list)
print("Start time of the activities:",start_time_list)
print("Finishing time of the activities:", finish_time_list)

result=find_maximum_activities(activity_list,start_time_list, finish_time_list)
print("The maximum set of activities that can be completed:",result)
