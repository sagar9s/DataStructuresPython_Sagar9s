#DSA-Assgn-17
def find_matches(country_name):
    result=[]
    for detail in match_list:
        cnty=detail.split(":")[0]
        if cnty==country_name:
            result.append(detail)
    return result        
        

def max_wins():
    world=[]
    t20=[]
    cham=[]
    dict1={}
    max1=0
    max2=0
    max3=0
    for detail in match_list:
        list1=detail.split(":")
        ty=list1[1]
        if ty=="WOR":
            world.append(int(list1[3])) 
        elif ty=="T20":
            t20.append(int(list1[3]))
        elif ty=="CHAM":
            cham.append(int(list1[3])) 
                      
    if world!=[]:
        max1=max(world)
    if cham!=[]:
        max2=max(cham)
    if t20!=[]:
        max3=max(t20) 
          
    world=[]
    t20=[]
    cham=[]
    
    for detail in match_list:
        list1=detail.split(":")
        
        if list1[1]=="WOR" and int(list1[3])==max1 :
            world.append(list1[0]) 
        if list1[1]=="CHAM" and int(list1[3])==max2:
            cham.append(list1[0])
        if list1[1]=="T20" and int(list1[3])==max3:
            t20.append(list1[0])    
            
    if world!=[]:
        dict1["WOR"]=world
    if cham!=[]:
        dict1["CHAM"]=cham
    if t20!=[]:
        dict1["T20"]=t20    
        
    return dict1        
        
                        
def find_winner(country1,country2):
    count1=0
    count2=0
    for detail in match_list:
        list1=detail.split(":")
        country=list1[0]
        wins=int(list1[3])
        if country==country1:
            count1+=wins
        elif country==country2:
            count2+=wins
    if count1>count2:
        return country1
    elif count1<count2:
        return country2
    else:
        return "Tie"        
    

#Consider match_list to be a global variable
match_list=['ENG:WOR:2:0', 'AUS:CHAM:5:2', 'PAK:T20:5:1', 'AUS:WOR:2:1', 'SA:T20:5:0', 'IND:T20:5:3', 'PAK:WOR:2:0', 'SA:WOR:2:0', 'SA:CHAM:5:1', 'IND:WOR:2:1']
#Pass different values to each function and test your program
print("The match status list details are:")
print(match_list)
print(find_matches("AUS"))
print(find_winner("AUS", "IND"))
print(max_wins())
print()