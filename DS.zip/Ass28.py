#DSA-Assgn-28

from datastruct.DataStructures import Stack,Queue

def check_triangle_number(queue1):
    lst=[]
    lst2=[]
    lst3=[]
    lst4=[]
    #Remove pass and write your logic here
    while(not queue1.is_empty()):
        lst.append(queue1.dequeue())
    for i in range(1,len(lst),2):
        lst2.append(lst[i])
    for i in range(0,len(lst),2):
        lst3.append(lst[i])
    for i in range(0,len(lst2)):
        sum1=0
        for j in range(1,lst3[i]+1):
            sum1+=j
        if sum1==lst2[i]:
            lst4.append(sum1)
    s1=Stack(queue1.get_max_size())
    for i in lst4:
        s1.push(i)
    return s1
    

    
        
        

#Pass different values of queue to the function and test your program
queue1=Queue(10)
queue1.enqueue(7)
queue1.enqueue(28)
queue1.enqueue(8)
queue1.enqueue(35)
queue1.enqueue(3)
queue1.enqueue(6)
queue1.enqueue(5)
queue1.enqueue(15)
queue1.enqueue(2)
queue1.enqueue(5)
print("The elements in the queue are:")
queue1.display()
check_triangle_number(queue1)
# Input queue (front->rear): 7,28,8,35,3,6,5,15,2,5
# Output stack ( top->bottom): 15,6,28