#DSA-Assgn-7

#This assignment needs DataStructures.py file in your package, you can get it from resources page

                                                 

def remove_duplicates(duplicate_list):
    #write your logic here
    temp=duplicate_list.get_head()
    lst=[]
    while(temp):
        if temp.get_data() not in lst:
            lst.append(temp.get_data())
        else:
            duplicate_list.delete(temp.get_data())
        temp=temp.get_next()
    return duplicate_list
        
    

#Add different values to the linked list and test your program
duplicate_list=LinkedList()
duplicate_list.add(30)
duplicate_list.add(40)
duplicate_list.add(40)
duplicate_list.add(40)
duplicate_list.add(40)

remove_duplicates(duplicate_list)
