#DSA-Assgn-1

def merge_list(list1, list2):
    str1=""

    lst=[]
    list2=list2[::-1]
    for i in range(0,len(list2)):
        if list1[i]==None: 
            list1[i]=""
            lst.append(str(list1[i])+str(list2[i]))
        elif list2[i]==None: 
            list2[i]=""
            lst.append(str(list1[i])+str(list2[i]))
        else:
            
            lst.append(str(list1[i])+str(list2[i]))
    for i in lst:
        str1+=str(i)+" " 
    return str1.strip()  
    
#Provide different values for the variables and test your program
list1=['A', 'app','a', 'd', 'ke', 'th', 'doc', 'awa']
list2=['y','tor','e','eps','ay',None,'le','n']
merged_data=merge_list(list1,list2)
print(merged_data)
