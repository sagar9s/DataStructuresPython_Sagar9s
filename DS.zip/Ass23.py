#DSA-Tryout

def generate_cards_per_type(card_type):
    #Remove pass and write your logic here
    pass

def generate_card_deck():
    #Remove pass and write your logic here
    pass

def shuffle_card_deck(cards_list):
    #Remove pass and write your logic here
    pass

def sort_cards_of_each_player(card_list):
    #Remove pass and write your logic here
    pass

def allocate_cards_to_players(cards_list):
    #Remove pass and write your logic here
    pass

def prepare_cards():
    #Remove pass and write your logic here
    pass

first_player=prepare_cards()
print("The first player is:",first_player)