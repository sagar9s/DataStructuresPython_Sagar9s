#DSA-Exer-23

def arrange_tickets(tickets_list):
    lst=[]
    lst2=[]
    lst3=[]
    lst4=[]
    for i in tickets_list:
        lst.append(int(i[1:]))
    lst.sort()
    for i in lst:
        lst2.append("T"+str(i))
    for i in range(1,21):
        lst3.append("T"+str(i))
    for i in lst3:
        if i in lst2:
            lst4.append(i)
        else:
            lst4.append("V")
    lst5=lst4[0:10]
    lst6=lst4[10:20]
    
    for i in lst6:
        if i=="V":
            lst6.remove(i)
    j=0
    for i in range(len(lst5)):
        if lst5[i]=="V":
            lst5[i]=lst6[j]
            j+=1
    return lst5
        
    
    

        
        

tickets_list = ['T5','T7','T1','T2','T8','T15','T17','T19','T6','T12','T13']
print("Ticket ids of all the available students :")
print(tickets_list)
result=arrange_tickets(tickets_list)
print()
print("Ticket ids of the ten students in Group-1:")
print(result)

