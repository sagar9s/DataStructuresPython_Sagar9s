#DSA-Assgn-21

from datastruct.DataStructures import Stack, Queue

#Global variables
flight_details=["AI890:BAN:MUM:1400","AI678:BAN:LON:1200","AI345:BAN:CAN:1410","AF780:BAN:AGF:1340","AI001:BAN:AUS:1500","AI404:BAN:NY:1220"]

passenger_details_dict=\
{"LW101":["Amanda","AI678","C7",25],"LW103":["John","AI345","A2",10],"LW107":["Alex","AI678","G5",12],\
"TW700":["Hary","AF780","D2",26],"LW167":["Kate","AI001","G3",25],"LT890":["Wade","AI404","G3",25],\
"TW677":["Preet","AF780","D3",25],"LA106":["Henry","AI001","B5",25.5],"LA104":["Ajay","AI001","A7",23],\
"LW202":["Amy","AI345","C3",24.5],"LT673":["Susan","AI404","J8",5],"TW709":["Tris","AF780","H5",22.5],\
"LA188":["Cameron","AI890","H4",22],"LA902":["Scofield","AI678","G4",23],"TW767":["Pom","AF780","H4",2],\
"LW787":["Burrows","AI890","B4",29],"LW898":["Sara","AI678","E4",14],"LW104":["Williams","AI890","C4",10] }
lst=[]
lst_flight_name=[]
lst_source=[]
lst_dest=[]
lst_dep_time=[]
for i in flight_details:
    lst.extend(i.split(":"))
for i in range(0,len(lst),4):
    lst_flight_name.append(lst[i])
for i in range(1,len(lst),4):
    lst_source.append(lst[i])
for i in range(2,len(lst),4):
    lst_dest.append(lst[i])
for i in range(3,len(lst),4):
    lst_dep_time.append(int(lst[i]))

def find_flights(flight_time):
    result=[]
    for flight in flight_details:
        list1=flight.split(":")
        if int(list1[3]) in range(flight_time,flight_time+200+1):
            result.append(flight)
    return result
                

def sort_flight_list(flight_list):
    
    temp=[]
    for detail in flight_list:
        list1=detail.split(":")
        temp.append(list1)
        
    temp.sort(key=lambda x:int(x[3]), reverse=False)    
    sorted_list=[]
    for i in temp:
        sorted_list.append(i[0]+":"+i[1]+":"+i[2]+":"+i[3])
    return sorted_list 
        
    

def get_passenger_details(flight_detail):
    lst=[]
    #Remove pass and write your logic here
    for k,v in passenger_details_dict.items():
        if v[1]==flight_detail[0:5]:
            lst.append(k)
    return lst

def security_check(passenger_pnr_list):
    lst=[]
    for i in passenger_pnr_list:
        for k,v in passenger_details_dict.items():
            if i==k:
                if v[3]>=0 and v[3]<=25:
                    lst.append(i)
    return lst
        
        

def sort_passengers(passenger_pnr_list):
    lst=[]
    lst2=[]
    lst3=[]
    lst4=[]
    lst5=[]
    for i in passenger_pnr_list:
        for k,v in passenger_details_dict.items():
            if i==k:
                lst.append(v[2])
    
    for i in lst:
        lst2.append(i[0:1])
    lst2=sorted(lst2)
    
    for i in lst2:
        for j in lst:
            if i==j[0]:
                lst3.append(j)
    for i in lst3:
        if i not in lst4:
            lst4.append(i)
    for i in lst4:
        for k,v in passenger_details_dict.items():
            if i==v[2]:
                lst5.append(k)
    return lst5
        


def boarding(passenger_pnr_list):
    q1=Queue(len(passenger_pnr_list))
    for i in passenger_pnr_list:
        q1.enqueue(i)
    return q1

def seating(passenger_queue):
    s1=Stack(passenger_queue.get_max_size())
    while(not passenger_queue.is_empty()):
        s1.push(passenger_queue.dequeue())
    return s1
    
        

print("The flight details :")
print(flight_details)
print()
print("The passenger details at the airport:")
print(passenger_details_dict)
print()
time=1130
print("Details of the flight between the timings",time,"and",time+200,"are:")
flight_list=find_flights(time)
flight_list=sort_flight_list(flight_list)
print(flight_list)
print()
print("Details of the passengers boarding the flights between the timings ",time,"and",(time+200),"are:")
print()
for i in range(0,len(flight_list)):
    flight_data=flight_list[i].split(':')
    flight_name=flight_data[0]

    passenger_pnr_list=get_passenger_details(flight_list[i])
    print("PNR details of the passengers boarding the flight",flight_name,":")
    print(passenger_pnr_list)

    print()
    updated_passenger_pnr_list=security_check(passenger_pnr_list)
    print("PNR details of the passengers of flight",flight_name," whose baggage has been cleared:")
    print(updated_passenger_pnr_list)

    sorted_passenger_pnr_list=sort_passengers(updated_passenger_pnr_list)
    print("PNR details of the passengers of flight",flight_name," sorted based on seating number:")
    print(sorted_passenger_pnr_list)

    print()
    print("The PNR details of the passengers at the queue",flight_name,":")
    passenger_queue=boarding(updated_passenger_pnr_list)
    passenger_queue.display()

    print()
    seating_stack=seating(passenger_queue)
    print("The PNR details of the passengers in the flight",flight_name,":")
    seating_stack.display()