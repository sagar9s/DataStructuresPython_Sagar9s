#DSA-Assgn-29


from datastruct.DataStructures import Stack

def stack_operation(input_stack):
    lst=[]
    while(not input_stack.is_empty()):
        lst.append(input_stack.pop())
    lst2=lst[-3:]
    lst3=lst[0: len(lst)-3]
    lst2.extend(lst3)
    lst2=lst2[::-1]
    s1=Stack(input_stack.get_max_size())
    for i in lst2:
        s1.push(i)
    return s1
        

#Pass different values of stack to the function and test your program
input_stack=Stack(5)
input_stack.push('E')
input_stack.push('D')
input_stack.push('C')
input_stack.push('B')
input_stack.push('A')

print("The elements in input stack are:")
input_stack.display()
print()
updated_stack=stack_operation(input_stack)
print("The elements in the updated stack are:")
updated_stack.display()
# Input stack (top->bottom): A,B,C,D,E
# Output stack (top->bottom) :C,D,E,A,B
