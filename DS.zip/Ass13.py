#DSA-Assgn-13

#This assignment needs DataStructures.py file in your package, you can get it from resources page

from datastruct.DataStructures import Stack

def change_smallest_value(number_stack):
    lst=[]
    #write your logic here
    while(not number_stack.is_empty()):
        lst.append(number_stack.pop())
    min1=min(lst)
    min1_count=lst.count(min1)
    temp=0
    while(temp<min1_count):
        number_stack.push(min1)
        if min1 in lst:
            lst.remove(min1)
        temp+=1
    lst=lst[::-1]
    
    for i in lst:
        number_stack.push(i)

    return number_stack

#Add different values to the stack and test your program
number_stack=Stack(8)
number_stack.push(7)
number_stack.push(8)
number_stack.push(5)
number_stack.push(66)
number_stack.push(5)
print("Initial Stack:")
number_stack.display()
change_smallest_value(number_stack)
print("After the change:")
number_stack.display()