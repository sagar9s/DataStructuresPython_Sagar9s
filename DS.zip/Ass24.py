#DSA-Assgn-24
import string
def count_decoding(digit_list):
    
    
    lst_alpha=[]
    lst_no=[]
    lst=[]
    str1=""
    str2=""
    str1+=string.ascii_uppercase[:26]
    for i in str1:
        lst_alpha.append(i)
    for i in range(1,27):
        lst_no.append(i)
    for i in digit_list:
        str2+=str(lst_alpha[lst_no.index(i)])
    lst.append(str2)
    
    
    
#Pass different values to the function and test your program
digit_list=[9,8,1,5]
print("Number of possible decodings for the given sequence is:",count_decoding(digit_list))