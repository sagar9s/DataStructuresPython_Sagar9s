#DSA-Exer-18

def find_next_min(num_list,start_index):
    lst=[]
    for i in range(start_index,len(num_list)):
        lst.append(num_list[i])
    ind=num_list.index(min(lst))
    return ind

#Pass different values to the function and test your program
num_list=[10,2,100,67]
start_index=1
print("Index of the next minimum element is", find_next_min(num_list,start_index))
