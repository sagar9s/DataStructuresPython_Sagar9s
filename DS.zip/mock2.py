#OOP-Assgn-202
#Do Not Change any part of the code provided to you
from abc import ABCMeta, abstractmethod
class CustomerDetails:
    customer_points_details ={'R1001': 892, 'R1003': 1352, 'R1002': 1956}
    mem_card_types = ['Silver','Gold','Platinum']
    card_type_points = [2,4,5]

    #To Trainee
    @staticmethod
    def get_card_points(card_type):
        cd=card_type.lower()
        lst=[]
        for i in CustomerDetails.mem_card_types:
            lst.append(i.lower())
        if cd in lst:
            return CustomerDetails.card_type_points[lst.index(cd)]
        else:
            return -1
            

    #To Trainee
    @staticmethod
    def add_point(cust_id,points):
        flag=False
        cust_id=cust_id[0].upper()+cust_id[1:]
        for k,v in CustomerDetails.customer_points_details.items():
            if cust_id==k:
                v+=points
                CustomerDetails.customer_points_details[k]=v
                flag=True
        if flag==False:
            cust_id=cust_id[0].upper()+cust_id[1:]
            CustomerDetails.customer_points_details[cust_id]=points
            

    #To Trainee
    @staticmethod
    def redeem_points(cust_id):
        lst_key=[]
        cd=cust_id.lower()
        for k,v in CustomerDetails.customer_points_details.items():
            lst_key.append(k.lower())
        if cd in lst_key:
            rv=0
            for k,v in CustomerDetails.customer_points_details.items():
                if k.lower()==cd:
                    if v>1500:
                        rv+=0.75*(v-1500)
#                         print(rv)
#                         v=1500
                        CustomerDetails.customer_points_details[k]=1500
        else:
            return 0
        return rv
            
        
class Customer(metaclass = ABCMeta):
    def __init__(self,cust_id,cust_name):
        self.__cust_id = cust_id
        self.__cust_name = cust_name

    def get_cust_id(self):
        return self.__cust_id

    def get_cust_name(self):
        return self.__cust_name

    @abstractmethod
    def validate_cust_details(self):
        pass


class RegisteredCustomer(Customer):
    def __init__(self,cust_id,cust_name,mem_card_type):
        super().__init__(cust_id, cust_name)
        self.__mem_card_type = mem_card_type

    def get_mem_card_type(self):
        return self.__mem_card_type

    #To Trainee
    def validate_cust_details(self):
        if self.get_cust_id()!=None and self.get_cust_name()!=None and self.get_mem_card_type()!=None:
            return True
        else:
            return False

class Bill:
    __counter = 5001
    def __init__(self,customer,redeemption_required):
        self.__customer = customer
        self.__redeemption_required = redeemption_required
        self.__bill_num = None

    def get_customer(self):
        return self.__customer

    def get_redeemption_required(self):
        return self.__redeemption_required

    def get_bill_num(self):
        return self.__bill_num

    #To Trainee
    def generate_bill_num(self):
        self.__bill_num=Bill.__counter
        Bill.__counter+=1

    #To Trainee
    def calculate_points(self,bill_amount):
        x=CustomerDetails.get_card_points(self.__customer.get_mem_card_type())
        if x!=-1:
            poin=bill_amount*x // 100
        else:
            return -1
        return poin
    

    #To Trainee
    def calculate_final_bill_amount(self,bill_amount):
        if self.__customer.validate_cust_details() and bill_amount>100:
            x=self.calculate_points(bill_amount)
            if x==-1:
                final_bill_amount=-1
                self.__bill_num=-1
            else:
                CustomerDetails.add_point(self.__customer.get_cust_id(),x)
                self.generate_bill_num()
                if self.get_redeemption_required():
                    y=CustomerDetails.redeem_points(self.__customer.get_cust_id())
                    final_bill_amount=bill_amount-y
                else:
                    final_bill_amount=bill_amount
        return final_bill_amount

cust_obj = RegisteredCustomer('r1003', 'John', 'GolD')
bill_obj = Bill(cust_obj, True)
final_bill_amount = bill_obj.calculate_final_bill_amount(10000)
print('Bill Num :',bill_obj.get_bill_num())
print('Final Bill Amount :',final_bill_amount)
print(CustomerDetails.customer_points_details)