#DSA-Assgn-18

def find_unknown_words(text,vocabulary):
    #Remove pass and write your logic here
    lst2=[]
    lst=text.split(" ")
    for i in lst:
        if i not in vocabulary:
            lst2.append(i)
    return set(lst2)

#Pass different values of text and vocabulary to the function and test your program
text="the sun rises in the east"
vocabulary = ["sun","in","east","doctor","day"]
unknown_words=find_unknown_words(text,vocabulary)
print("The unknown words in the file are:",unknown_words)
