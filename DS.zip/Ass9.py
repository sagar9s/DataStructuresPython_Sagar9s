#DSA-Assgn-9

#This assignment needs DataStructures.py file in your package, you can get it from resources page

from datastruct.DataStructures import LinkedList

def reverse_linkedlist(reverse_list):
    temp=reverse_list.get_head()
    result=LinkedList()
    res=[]
    while(temp):
        res.append(temp)
        temp=temp.get_next()
    res=res[::-1]
        
    for i in res:
        result.add(i.get_data())
        
    reverse_list=result
    return reverse_list

#Add different values to the linked list and test your program
reverse_list=LinkedList()
reverse_list.add(10)
reverse_list.add(15)
reverse_list.add(14)
reverse_list.add(28)
reverse_list.add(30)
reversed_linkedlist=reverse_linkedlist(reverse_list)
reversed_linkedlist.display()
