#PF-Prac-20
def ducci_sequence(test_list,n):
    if n>=1:
        
        lst2=[]
        lst3=[]
        t_list=test_list
        for i in range(1,len(test_list)):
            lst2.append(test_list[i]-test_list[i-1])
        lst2.append(t_list[len(test_list)-1]-t_list[0])
        final_list.append(lst2)
        ducci_sequence(lst2, n-1)
    else:
        return final_list[len(final_list)-1]
final_list=[]
print(ducci_sequence([0, 653, 1854, 4063] , 3))  
