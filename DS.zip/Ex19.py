#DSA-Exer-19

def swap(num_list, first_index, second_index):
    a=num_list[first_index]
    b=num_list[second_index]
    a,b=b,a
    num_list[first_index]=a
    num_list[second_index]=b


def find_next_min(num_list,start_index):
    lst=[]
    #Remove pass and copy the code written earlier for this function
    for i in range(start_index,len(num_list)):
        lst.append(num_list[i])
    return num_list.index(min(lst))

def selection_sort(num_list):
    lst=num_list.sort()
    return lst


#Pass different values to the function and test your program
num_list=[8,2,19,34,23, 67, 91]
print("Before sorting;",num_list)
selection_sort(num_list)
print("After sorting:",num_list)
