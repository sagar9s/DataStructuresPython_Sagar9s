#DSA-Assgn-302


from datastruct.DataStructures import *

def queue_ordering(input_queue,input_stack):
    lst_stack=[]
    lst_queue=[]
    while(not input_stack.is_empty()):
        lst_stack.append(input_stack.pop())
    while(not input_queue.is_empty()):
        lst_queue.append(input_queue.dequeue())
    for i in lst_stack:
        if i==2:
            lst=[]
            x=lst_queue.pop()
            lst.append(x)
            lst.extend(lst_queue)
            lst_queue=lst
            
        elif i==1:
            x=lst_queue[0]
            lst_queue=lst_queue[1:len(lst_stack)+1]
            lst_queue.append(x)

    
    output_queue=Queue(input_queue.get_max_size())
    for i in lst_queue:
        output_queue.enqueue(i)
            
    
    return output_queue

#You may modify the below code for testing
input_stack=Stack(4)
input_stack.push(1)
input_stack.push(2)
input_stack.push(1)
input_stack.push(2)




input_queue=Queue(5)
input_queue.enqueue('M')
input_queue.enqueue('N')
input_queue.enqueue('O')
input_queue.enqueue('X')

input_queue.enqueue('Y')

output_queue=queue_ordering(input_queue, input_stack)
output_queue.display()
