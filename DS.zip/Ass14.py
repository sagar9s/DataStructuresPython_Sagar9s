#DSA-Assgn-14

#This assignment needs DataStructures.py file in your package, you can get it from resources page

from datastruct.DataStructures import Queue

def check_numbers(number_queue):
    #write your logic here
    number_queue1=Queue(number_queue.get_max_size())
    while(not number_queue.is_empty()):
        x=number_queue.dequeue()
        cnt=0
        for i in range(1,11):
            if x%i==0:
                cnt+=1
        if cnt==10:
            number_queue1.enqueue(x)
    

    return number_queue1

#Add different values to the queue and test your program
number_queue=Queue(5)
number_queue.enqueue(13983)
number_queue.enqueue(10080)
number_queue.enqueue(7113)
number_queue.enqueue(2520)
number_queue.enqueue(2500)
check_numbers(number_queue)
