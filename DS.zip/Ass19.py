#DSA-Assgn-19


def last_instance(num_list,start,end,key):
    #Remove pass and write your logic here

    x=-1
    num_list=num_list[::-1]
    for i in num_list:
        if i==key:
            x=num_list.index(i)
            break
    
    if x!=-1:
        x=num_list.index(i)
        return (len(num_list)-1)-x
    return -1

num_list=[1,1,2,2,3,4,5,5,5,5]
start=0
end=len(num_list)-1
key=5   
result=last_instance(num_list,start,end,key)

if(result!=-1):
    print("The index position of the last occurrence of the number:",result)
else:
    print("Number not found")
