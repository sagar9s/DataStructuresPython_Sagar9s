#DSA-Assgn-5

#This assignment needs DataStructures.py file in your package, you can get it from resources page

from datastruct.DataStructures import LinkedList

def create_new_sentence(word_list):
    new_sentence=""
    temp=word_list.get_head()
    while(temp is not None):
        if temp.get_data()=='/' and temp.get_next().get_data()=='*' or temp.get_data()=='*' and temp.get_next().get_data()=='/' or temp.get_data()=='/' and temp.get_next().get_data()=='/' or temp.get_data()=='*' and temp.get_next().get_data()=='*':
            temp.set_data(" ")
            word_list.delete(temp.get_next().get_data())
            temp.get_next().set_data(str(temp.get_next().get_data()).upper())
            new_sentence+=str(temp.get_data())
            temp=temp.get_next()
        elif temp.get_data()=='/':
            temp.set_data(" ")
            new_sentence+=str(temp.get_data())
            temp=temp.get_next()
        elif temp.get_data()=='*':
            temp.set_data(" ")
            new_sentence+=str(temp.get_data())
            temp=temp.get_next()
        else:
            new_sentence+=str(temp.get_data())
            temp=temp.get_next()
    
    
        
    
    return new_sentence

word_list=LinkedList()
word_list.add("T")
word_list.add("h")
word_list.add("e")
word_list.add("/")
word_list.add("*")
word_list.add("s")
word_list.add("k")
word_list.add("y")
word_list.add("*")
word_list.add("i")
word_list.add("s")
word_list.add("/")
word_list.add("/")
word_list.add("b")
word_list.add("l")
word_list.add("u")
word_list.add("e")
result=create_new_sentence(word_list)
print(result)