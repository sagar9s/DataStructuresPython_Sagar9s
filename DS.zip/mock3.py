#DSA-Assgn-303
#This assignment needs DataStructures.py file in your package, you can get it from resources page
from datastruct.DataStructures import LinkedList,Queue,Stack
def regenerate_stack(input_stack):
    output_stack = Stack(input_stack.get_max_size())
    lst=[]
    lst2=[]
    l3=[]
    while(not input_stack.is_empty()):
        lst.append(input_stack.pop())
    for i in range(len(lst)):
        if lst[i]=='@':
            lst[i]='.'
    ind=lst.index('.')
    indx=lst[::-1].index('.')
    ind2=(len(lst)-1)-indx
    l1=lst[0:ind]
    l2=lst[ind:ind2+1]
    for i in l2:
        l3.append(i.upper())
    l4=lst[ind2+1:]
    flist=l1+l3+l4
    flist=flist[::-1]
    for i in flist:
        output_stack.push(i)
    
        
        
    




    return output_stack
#You can modify the input to test your code
input_stack = Stack(10)
input_stack.push('stay')
input_stack.push('Happy')
input_stack.push('@')
input_stack.push('infosys')
input_stack.push('in')
input_stack.push('are')
input_stack.push('you')
input_stack.push('@')
input_stack.push('WelCome')
input_stack.push('hi')
output_stack = regenerate_stack(input_stack)
output_stack.display()