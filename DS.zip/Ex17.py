#DSA-Exer-17

def swap(num_list, first_index, second_index):
    a=num_list[first_index]
    b=num_list[second_index]
    a,b=b,a
    num_list[first_index]=a
    num_list[second_index]=b
    


#Pass different values to the function and test your program
num_list=[2,3,89,45,67]
print("List before swapping:",num_list)
swap(num_list, 1, 2)
print("List after swapping:",num_list)
