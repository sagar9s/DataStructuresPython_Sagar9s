from itertools import combinations
l1=[45, 78, 22, 42, 12, 3, 78]
l2=[]
l3=[]
l4=[]
for i in range(1,len(l1)+1):
    c=list(combinations(l1,i))
    l2.extend(c)
print(l2)
for i in l2:
    temp = list(i)[:]
    sorted(i)
    if sorted(i)==temp:
        l3.append(i)
print(l3)
for i in l3:
    l4.append(sum(i))
print(max(l4))

